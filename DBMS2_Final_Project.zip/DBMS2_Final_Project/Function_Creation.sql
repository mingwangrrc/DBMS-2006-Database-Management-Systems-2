/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 ** Description: 
 ** This script creates a function named GetTotalOrdersByAge in the DBMS_Final_Project database.
 ** The function calculates the total number of orders placed by customers of a specific age or within an age range.
 ** Demonstrations include finding the total orders for customers of a specific age and within an age range.
 **/

USE DBMS_Final_Project;
GO

-- Create a function to count the total number of orders by customers of a certain age or within an age range
CREATE OR ALTER FUNCTION GetTotalOrdersByAge (@MinAge INT, @MaxAge INT = NULL)
RETURNS INT
AS
BEGIN
    IF @MaxAge IS NULL
    BEGIN
        -- If only min age is provided, consider it as a specific age
        SET @MaxAge = @MinAge;
    END

    -- Return the total orders for customers within the age range
    RETURN (
        SELECT COUNT(*)
        FROM Orders
        WHERE CustomerID IN (SELECT CustomerID FROM Customers WHERE Age BETWEEN @MinAge AND @MaxAge)
    );
END;
GO

-- Demonstration 1: Get the total number of orders for customers exactly 25 years old
SELECT dbo.GetTotalOrdersByAge(25, NULL) AS TotalOrdersForAge25;

-- Demonstration 2: Get the total number of orders for customers aged between 25 and 30 years
SELECT dbo.GetTotalOrdersByAge(25, 30) AS TotalOrdersForAges25To30;
