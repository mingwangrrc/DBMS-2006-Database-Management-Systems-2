CREATE TABLE Customers (
    CustomerID INT NOT NULL,
    Age INT NOT NULL,
    Gender VARCHAR(10) NOT NULL,
    MaritalStatus VARCHAR(20) NOT NULL,
    Occupation VARCHAR(50) NOT NULL,
    MonthlyIncome VARCHAR(50),
    EducationalQualifications VARCHAR(50) NOT NULL,
    FamilySize INT NOT NULL,
    CONSTRAINT PK_Customers PRIMARY KEY (CustomerID)
);




CREATE TABLE Locations (
    LocationID INT NOT NULL,
    Latitude DECIMAL(9,6) NOT NULL,
    Longitude DECIMAL(9,6) NOT NULL,
    PinCode VARCHAR(20) NOT NULL,
    CONSTRAINT PK_Locations PRIMARY KEY (LocationID)
);




CREATE TABLE Orders (
    OrderID INT NOT NULL,
    CustomerID INT NOT NULL,
    LocationID INT NOT NULL,
    OrderStatus VARCHAR(10) NOT NULL,
    CONSTRAINT PK_Orders PRIMARY KEY (OrderID),
    CONSTRAINT FK_Orders_Customers FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    CONSTRAINT FK_Orders_Locations FOREIGN KEY (LocationID) REFERENCES Locations(LocationID)
);




CREATE TABLE FamilySize (
    FamilySizeID INT NOT NULL,
    NumberOfMembers INT NOT NULL,
    CONSTRAINT PK_FamilySize PRIMARY KEY (FamilySizeID)
);





CREATE TABLE Feedback (
    FeedbackID INT NOT NULL,
    OrderID INT NOT NULL,
    FeedbackType VARCHAR(20) NOT NULL,
    CONSTRAINT PK_Feedback PRIMARY KEY (FeedbackID),
    CONSTRAINT FK_Feedback_Orders FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);
