/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 **/

USE DBMS_Final_Project;
GO

/** 
 ** Description:
 ** This script creates or alters a stored procedure named GetCustomerDetails in the DBMS_Final_Project database.
 ** The stored procedure is designed to retrieve detailed information about a specific customer based on their CustomerID.
 ** This procedure is useful for obtaining a complete view of a customer's information stored in the Customers table.
 **/
-- Creating or altering the GetCustomerDetails stored procedure
CREATE OR ALTER PROCEDURE GetCustomerDetails
    @CustomerID INT
AS
BEGIN
    SELECT *
    FROM Customers
    WHERE CustomerID = @CustomerID;
END;
GO

-- Demonstrating the usage of the GetCustomerDetails stored procedure
-- Retrieves details for the customer with CustomerID = 10001
EXEC GetCustomerDetails 10001;
GO


/**
 ** This script creates a stored procedure named UpdateCustomerOrderStatus.
 ** The procedure updates the order status for all orders placed by a specific customer.
 ** It uses a transaction to ensure that all updates are either completely successful or completely rolled back.
 ** This ensures data integrity in the Orders table.
 **/
CREATE OR ALTER PROCEDURE UpdateCustomerOrderStatus
    @CustomerID INT,
    @NewStatus VARCHAR(10)
AS
BEGIN
    BEGIN TRY
        -- Start the transaction
        BEGIN TRANSACTION;
        
        -- Update the order status for all orders placed by the specified customer
        UPDATE Orders
        SET OrderStatus = @NewStatus
        WHERE CustomerID = @CustomerID;
        
        -- Commit the transaction if no errors occur
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Roll back the transaction in case of an error
        ROLLBACK TRANSACTION;
        
        -- Return the error information
        SELECT 
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_MESSAGE() AS ErrorMessage;
    END CATCH;
END;
GO

-- Example: we want to update all orders for customer with ID 10001 to 'Completed'
EXEC UpdateCustomerOrderStatus @CustomerID = 10001, @NewStatus = 'Completed';
GO

-- Check if the updates were applied
SELECT * FROM Orders WHERE CustomerID = 10001;