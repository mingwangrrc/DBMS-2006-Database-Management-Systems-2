/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 ** Descriptions: The purpose of the trigger CheckAgeOnCustomerInsert is to enforce a business rule at the database level 
 **	that customers must be at least 18 years old to be entered into the Customers table. 
 **/

USE DBMS_Final_Project;
GO

-- Drop the trigger if it already exists
DROP TRIGGER IF EXISTS CheckAgeOnCustomerInsert;

-- Create the trigger to enforce age constraint
CREATE TRIGGER CheckAgeOnCustomerInsert
ON Customers
AFTER INSERT
AS
BEGIN
    IF EXISTS(SELECT * FROM inserted WHERE Age < 18)
    BEGIN
        RAISERROR ('Customers must be at least 18 years old.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

-- Attempt to insert a customer who is under 18 years old
-- This should fail due to the trigger constraint
INSERT INTO Customers (CustomerID, Age, Gender, MaritalStatus, Occupation, MonthlyIncome, EducationalQualifications, FamilySize)
VALUES (12345, 17, 'Female', 'Single', 'Student', 'No Income', 'High School', 1);
GO

-- This should succeed as the age is 18+
INSERT INTO Customers (CustomerID, Age, Gender, MaritalStatus, Occupation, MonthlyIncome, EducationalQualifications, FamilySize)
VALUES (2, 25, 'Male', 'Single', 'Professional', '$50000', 'Masters', 3);
GO

-- Check the contents of the Customers table to verify the results
SELECT * FROM Customers;
GO

-- remove test data that was used to check the trigger functionality
DELETE FROM Customers WHERE CustomerID = 2;
