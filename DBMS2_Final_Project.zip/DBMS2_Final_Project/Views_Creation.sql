/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 ** Description: This script creates two views for the DBMS_Final_Project database.
 ** The first view (View_AdultCustomers) is designed to display only customers who are 18 years old or older.
 ** The second view (View_PositiveFeedbackOrders) shows orders that have received positive feedback.
 ** These views are intended to simplify data access and analysis for specific use cases.
 **/

USE DBMS_Final_Project;
GO

-- Creating a view to list all adult customers
-- This view filters the Customers table to show only customers who are 18 years or older
CREATE OR ALTER VIEW View_AdultCustomers AS
SELECT 
    CustomerID, 
    Age, 
    Gender, 
    MaritalStatus, 
    Occupation, 
    MonthlyIncome, 
    EducationalQualifications, 
    FamilySize
FROM 
    Customers
WHERE 
    Age >= 18;
GO

-- Creating a view to list orders with positive feedback
-- This view joins Orders with Feedback to show only those orders that have received 'Positive' feedback
CREATE OR ALTER VIEW View_PositiveFeedbackOrders AS
SELECT 
    O.OrderID, 
    O.CustomerID, 
    O.LocationID, 
    O.OrderStatus,
    F.FeedbackType
FROM 
    Orders O
INNER JOIN Feedback F ON O.OrderID = F.OrderID
WHERE 
    F.FeedbackType = 'Positive';
GO

-- Testing the View_AdultCustomers view by selecting all records from it
-- This should return all customers who are 18 years old or older
SELECT * FROM View_AdultCustomers;
GO

-- Testing the View_PositiveFeedbackOrders view by selecting all records from it
-- This should return all orders that have received positive feedback
SELECT * FROM View_PositiveFeedbackOrders;
GO
