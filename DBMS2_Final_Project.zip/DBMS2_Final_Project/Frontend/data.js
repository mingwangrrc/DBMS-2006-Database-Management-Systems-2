document.addEventListener("DOMContentLoaded", function() {
    // Fetch data from the server
    fetch('retrieve_data.php')
        .then(response => response.json())
        .then(data => {
            // Process the data and generate HTML table rows
            let html = '';
            data.forEach(row => {
                html += '<tr>';
                html += '<td>' + row.CustomerID + '</td>';
                html += '<td>' + row.Age + '</td>';
                html += '<td>' + row.Gender + '</td>';
                html += '<td>' + row.MaritalStatus + '</td>';
                // Add more table cells as needed
                html += '</tr>';
            });
            // Append the HTML to the table
            document.getElementById('customerTable').innerHTML += html;
        })
        .catch(error => console.error('Error:', error));
});
