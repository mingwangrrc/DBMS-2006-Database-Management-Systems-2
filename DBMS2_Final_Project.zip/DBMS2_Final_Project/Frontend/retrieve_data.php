<?php
// Establish a connection to the database
$servername = "DESKTOP-F51IDPK"; // Change this to your database server
$dbname = "DBMS_Final_Project"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve data from the Customers table
$sql = "SELECT * FROM Customers";
$result = $conn->query($sql);

// Fetch data as associative array
$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($data);
?>
