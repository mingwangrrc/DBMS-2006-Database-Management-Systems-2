/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 ** Description: This script is used to create indexes on the Customers and Orders tables.
 ** The purpose of these indexes is to improve query performance on commonly searched fields.
 **/

USE DBMS_Final_Project;
GO

-- Create an index on the Age column of the Customers table.
-- This index can improve performance for queries filtering or sorting by age.
CREATE INDEX IDX_Customers_Age ON Customers(Age);
GO

-- Create an index on the OrderStatus column of the Orders table.
-- This index is useful for queries that filter by the status of orders,
-- such as finding all orders that are 'Pending', 'Confirmed', or 'Delivered'.
CREATE INDEX IDX_Orders_Status ON Orders(OrderStatus);
GO

-- Run a query that should use the index
SELECT * FROM Customers WHERE Age > 30;
GO

-- Query to find all orders with 'Pending' status
SELECT * FROM Orders WHERE OrderStatus = 'Yes';

