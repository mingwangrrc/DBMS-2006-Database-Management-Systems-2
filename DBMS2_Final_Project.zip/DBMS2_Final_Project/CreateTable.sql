/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 **/

--CREATE DATABASE DBMS_Final_Project; 
USE DBMS_Final_Project;
GO

DROP TABLE IF EXISTS FamilySize;
DROP TABLE IF EXISTS Feedback;
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS Locations;

/********** Customers **********/
CREATE TABLE Customers (
    CustomerID INT NOT NULL,
    Age INT NOT NULL,
    Gender VARCHAR(10) NOT NULL,
    MaritalStatus VARCHAR(20) NOT NULL,
    Occupation VARCHAR(50) NOT NULL,
    MonthlyIncome VARCHAR(50),
    EducationalQualifications VARCHAR(50) NOT NULL,
    FamilySize INT NOT NULL,
    CONSTRAINT PK_Customers PRIMARY KEY (CustomerID)
);
GO

BULK INSERT Customers
FROM 'C:\Users\Ming Wang\Desktop\DBMS2_Final_Project\Customers.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- check constraint to ensure that Age is within a reasonable range
ALTER TABLE Customers
ADD CONSTRAINT CHK_Customers_Age CHECK (Age >= 0 AND Age <= 130);

/*
/********** Tests **********/
--DELETE the Test Value
DELETE FROM Customers WHERE CustomerID = 1;

-- This should fail, as the age is outside of the valid range
INSERT INTO Customers (CustomerID, Age, Gender, MaritalStatus, Occupation, MonthlyIncome, EducationalQualifications, FamilySize)
VALUES (2, 131, 'Male', 'Single', 'Student', 'No Income', 'Post Graduate', 1);

-- This should succeed, as the age is within the range
INSERT INTO Customers (CustomerID, Age, Gender, MaritalStatus, Occupation, MonthlyIncome, EducationalQualifications, FamilySize)
VALUES (1, 25, 'Female', 'Single', 'Student', 'No Income', 'Post Graduate', 2);
SELECT * FROM Customers;
*/

/********** Locations **********/
CREATE TABLE Locations (
    LocationID INT NOT NULL,
    Latitude DECIMAL(9,6) NOT NULL,
    Longitude DECIMAL(9,6) NOT NULL,
    PinCode VARCHAR(20) NOT NULL,
    CONSTRAINT PK_Locations PRIMARY KEY (LocationID)
);
GO

BULK INSERT Locations
FROM 'C:\Users\Ming Wang\Desktop\DBMS2_Final_Project\Locations.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Orders **********/
CREATE TABLE Orders (
    OrderID INT NOT NULL,
    CustomerID INT NOT NULL,
    LocationID INT NOT NULL,
    OrderStatus VARCHAR(10) NOT NULL,
    CONSTRAINT PK_Orders PRIMARY KEY (OrderID),
    CONSTRAINT FK_Orders_Customers FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    CONSTRAINT FK_Orders_Locations FOREIGN KEY (LocationID) REFERENCES Locations(LocationID)
);
GO

BULK INSERT Orders
FROM 'C:\Users\Ming Wang\Desktop\DBMS2_Final_Project\Orders.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

/********** FamilySize **********/
CREATE TABLE FamilySize (
    FamilySizeID INT NOT NULL,
    NumberOfMembers INT NOT NULL,
    CONSTRAINT PK_FamilySize PRIMARY KEY (FamilySizeID)
);
GO

BULK INSERT FamilySize
FROM 'C:\Users\Ming Wang\Desktop\DBMS2_Final_Project\FamilySize.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

/********** Feedback **********/
CREATE TABLE Feedback (
    FeedbackID INT NOT NULL,
    OrderID INT NOT NULL,
    FeedbackType VARCHAR(20) NOT NULL,
    CONSTRAINT PK_Feedback PRIMARY KEY (FeedbackID),
    CONSTRAINT FK_Feedback_Orders FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);
GO

BULK INSERT Feedback
FROM 'C:\Users\Ming Wang\Desktop\DBMS2_Final_Project\Feedback.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/* Sample Online Orders */
SELECT * FROM Customers;
SELECT * FROM FamilySize;
SELECT * FROM Orders;
SELECT * FROM Feedback;
SELECT * FROM Locations;

SELECT 
    C.CustomerID AS 'Customer ID',
    C.Age AS 'Age',
    C.Gender AS 'Gender',
    C.MaritalStatus AS 'Marital Status',
    C.Occupation AS 'Occupation',
    C.MonthlyIncome AS 'Monthly Income',
    C.EducationalQualifications AS 'Educational Qualifications',
    FS.NumberOfMembers AS 'Family Size',
    L.Latitude AS 'Latitude',
    L.Longitude AS 'Longitude',
    L.PinCode AS 'Pin Code',
    O.OrderID AS 'Order ID',
    O.OrderStatus AS 'Order Status',
    F.FeedbackType AS 'Feedback'
FROM Customers C
INNER JOIN FamilySize FS ON C.FamilySize = FS.NumberOfMembers
INNER JOIN Orders O ON C.CustomerID = O.CustomerID
INNER JOIN Feedback F ON O.OrderID = F.OrderID
INNER JOIN Locations L ON O.LocationID = L.LocationID;
GO