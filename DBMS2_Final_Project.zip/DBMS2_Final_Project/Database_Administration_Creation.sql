/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 **/

 /********** Database Administration  **********/
USE DBMS_Final_Project;
GO

-- 6.1.3 Create and demonstrate more than 2 Roles/Users interacting with database objects:

-- Create Login for JenniferGarnet
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'JenniferGarnet')
BEGIN
    CREATE LOGIN JenniferGarnet WITH PASSWORD = 'mingwang';
END;
GO

-- Create Login for PhilBlat
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'PhilBlat')
BEGIN
    CREATE LOGIN PhilBlat WITH PASSWORD = 'mingwang';
END;
GO

-- Create Login for RhondaSeymore
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'RhondaSeymore')
BEGIN
    CREATE LOGIN RhondaSeymore WITH PASSWORD = 'mingwang';
END;
GO

-- Create Users
-- JenniferGarnet
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'jGarnet')
BEGIN
    CREATE USER jGarnet FOR LOGIN JenniferGarnet;
END
ELSE
BEGIN
    ALTER USER jGarnet WITH LOGIN = JenniferGarnet;
END;
GO

-- PhilBlat
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'pBlat')
BEGIN
    CREATE USER pBlat FOR LOGIN PhilBlat;
END
ELSE
BEGIN
    ALTER USER pBlat WITH LOGIN = PhilBlat;
END;
GO

-- RhondaSeymore
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'rSeymore')
BEGIN
    CREATE USER rSeymore FOR LOGIN RhondaSeymore;
END
ELSE
BEGIN
    ALTER USER rSeymore WITH LOGIN = RhondaSeymore;
END;
GO

-- Create Roles
CREATE ROLE receptionist_role;
CREATE ROLE salesperson_role;
CREATE ROLE salesmanager_role;
GO

-- Assign Permissions
GRANT SELECT ON dbo.Customers TO receptionist_role;
GRANT SELECT ON dbo.Orders TO receptionist_role;
GRANT SELECT ON dbo.Locations TO receptionist_role;

GRANT SELECT ON dbo.Customers TO salesperson_role;
GRANT SELECT, INSERT ON dbo.Orders TO salesperson_role;

GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Customers TO salesmanager_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Orders TO salesmanager_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Locations TO salesmanager_role;
GO

-- Assign Users to Roles
ALTER ROLE receptionist_role ADD MEMBER jGarnet;
ALTER ROLE salesperson_role ADD MEMBER pBlat;
ALTER ROLE salesmanager_role ADD MEMBER rSeymore;
GO

-- Test Permissions
-- Impersonate Jennifer Garnet
EXECUTE AS USER = 'jGarnet';
SELECT * FROM dbo.Customers; -- Should succeed
SELECT * FROM dbo.Orders; -- Should succeed
SELECT * FROM dbo.Locations; -- Should succeed

DELETE FROM dbo.Orders WHERE OrderID = 391; -- Should fail

UPDATE dbo.Customers SET Gender = 'Female' WHERE CustomerID = 10001; -- Should fail
REVERT;

-- Impersonate Phil Blat
EXECUTE AS USER = 'pBlat';
SELECT * FROM dbo.Customers; -- Should succeed

INSERT INTO dbo.Orders (OrderID, CustomerID, LocationID, OrderStatus) VALUES (390, 10001, 20001, 'Pending'); -- Should succeed
SELECT * FROM dbo.Orders;

DELETE FROM dbo.Orders WHERE OrderID = 391; -- Should fail

UPDATE dbo.Customers SET Gender = 'Female' WHERE CustomerID = 10001; -- Should fail
REVERT;

-- Impersonate Rhonda Seymore
EXECUTE AS USER = 'rSeymore';
SELECT * FROM dbo.Customers; -- Should succeed

INSERT INTO dbo.Orders (OrderID, CustomerID, LocationID, OrderStatus) VALUES (391, 10001, 20001, 'Pending'); -- Should succeed
SELECT * FROM dbo.Orders;

DELETE FROM dbo.Orders WHERE OrderID = 391; -- Should succeed
SELECT * FROM dbo.Orders;

UPDATE dbo.Customers SET Gender = 'male' WHERE CustomerID = 10001; -- Should succeed
SELECT * FROM dbo.Customers;
REVERT;
