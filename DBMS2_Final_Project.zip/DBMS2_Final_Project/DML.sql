/**
 ** Course: DBMS-2006 Database Management Systems 2
 ** Name: Ming Wang
 ** Final Project
 ** Date: 2024-4-11
 **/

 /********** DML **********/
Use DBMS_Final_Project;
GO

 -- 5.1.1 Write a query (inner join) to retrieve data from 2 tables
 SELECT 
    C.CustomerID AS 'Customer ID',
    C.Age AS 'Age',
    C.Gender AS 'Gender',
    C.MaritalStatus AS 'Marital Status',
    C.Occupation AS 'Occupation',
    C.MonthlyIncome AS 'Monthly Income',
    C.EducationalQualifications AS 'Educational Qualifications',
    FS.NumberOfMembers AS 'Family Size',
    L.Latitude AS 'Latitude',
    L.Longitude AS 'Longitude',
    L.PinCode AS 'Pin Code',
    O.OrderID AS 'Order ID',
    O.OrderStatus AS 'Order Status',
    F.FeedbackType AS 'Feedback'
FROM Customers C
INNER JOIN FamilySize FS ON C.FamilySize = FS.NumberOfMembers
INNER JOIN Orders O ON C.CustomerID = O.CustomerID
INNER JOIN Feedback F ON O.OrderID = F.OrderID
INNER JOIN Locations L ON O.LocationID = L.LocationID;


-- 5.2.2 Write a query (outer join) to retrieve data from 3 or more tables
SELECT 
    C.CustomerID AS 'Customer ID',
    C.Age AS 'Age',
    C.Gender AS 'Gender',
    C.MaritalStatus AS 'Marital Status',
    C.Occupation AS 'Occupation',
    C.MonthlyIncome AS 'Monthly Income',
    C.EducationalQualifications AS 'Educational Qualifications',
    FS.NumberOfMembers AS 'Family Size',
    L.Latitude AS 'Latitude',
    L.Longitude AS 'Longitude',
    L.PinCode AS 'Pin Code',
    O.OrderID AS 'Order ID',
    O.OrderStatus AS 'Order Status',
    F.FeedbackType AS 'Feedback'
FROM Customers C
LEFT JOIN FamilySize FS ON C.FamilySize = FS.NumberOfMembers
LEFT JOIN Orders O ON C.CustomerID = O.CustomerID
LEFT JOIN Feedback F ON O.OrderID = F.OrderID
LEFT JOIN Locations L ON O.LocationID = L.LocationID;

--5.3.1 Write a non-correlated subquery
SELECT * FROM Orders
WHERE CustomerID IN (
    SELECT CustomerID FROM Customers WHERE Age > 30
);


-- 5.4.1 Write a correlated subquery
SELECT 
    CustomerID,
    Age,
    (SELECT COUNT(*) FROM Orders WHERE Orders.CustomerID = Customers.CustomerID) AS 'Order Count'
FROM Customers;

-- 5.5.2 Aggregate the data in some way
SELECT 
    Gender,
    MaritalStatus,
    AVG(Age) AS 'Average Age',
    MAX(Age) AS 'Max Age',
    MIN(Age) AS 'Min Age'
FROM Customers
GROUP BY Gender, MaritalStatus;
