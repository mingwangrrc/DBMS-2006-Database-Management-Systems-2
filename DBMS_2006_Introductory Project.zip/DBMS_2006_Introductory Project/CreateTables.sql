/**
 ** Course: DBMS-2006 (248228) Database Management Systems 2
 ** Name: Ming Wang
 ** Introductory Project
 ** Date: 2024-03-01
 **
 ** Important Notes:
 ** This script includes two versions for creating database tables and importing data from CSV files.
 ** 
 ** Version 1:
 ** - Directly specifies the file paths for the BULK INSERT commands.
 ** - This version requires manual adjustment of the file paths in each BULK INSERT statement 
 **   to match the location of the CSV files on the local system.
 **
 ** Version 2:
 ** - Utilizes dynamic SQL to construct BULK INSERT commands, allowing for a centralized file path definition.
 ** - Only requires the modification of the @filePath variable to reflect the location of the CSV files.
 ** Please choose the version that best suits your environment. For ease of use and adaptability, especially 
 ** when running the script in different environments, Version 2 is recommended. Modify the @filePath variable 
 ** at the beginning of Version 2 to point to the directory containing your CSV files.
 **
 **/

/************************************************************ Version 1 ************************************************************/

--Create Database IntroductoryProject;
USE IntroductoryProject;
GO

--Drop the table if it already exists
DROP TABLE IF EXISTS Ticket;
DROP TABLE IF EXISTS Trip;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Gender;
DROP TABLE IF EXISTS City;
DROP TABLE IF EXISTS State;
DROP TABLE IF EXISTS Class;
DROP TABLE IF EXISTS Station;
DROP TABLE IF EXISTS Train;
GO


/********** State Table Creation **********/
CREATE TABLE State (
    state_id INT PRIMARY KEY IDENTITY(1,1),
    state_name NVARCHAR(30) NOT NULL UNIQUE
);
GO

BULK INSERT State
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\StateCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** City Table Creation **********/
CREATE TABLE City (
    city_id INT PRIMARY KEY IDENTITY(1,1),
    city_name NVARCHAR(30) NOT NULL,
    state_id INT NOT NULL,
    FOREIGN KEY (state_id) REFERENCES State(state_id)
);
GO

BULK INSERT City
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\CityCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Design Decision: Separate Gender and Customer Tables
/*
   Keeping the Gender table separate from Customer for:
   1. Normalization: Avoids redundancy and maintains data integrity.
   2. Flexibility: Easier to update and manage gender-related data.
   3. Scalability: Facilitates future enhancements without impacting the Customer table structure.
   4. Efficient Reporting: Simplifies queries and analysis based on gender.
   This approach ensures a more maintainable and scalable database design.
*/
/********** Gender Table Creation **********/
CREATE TABLE Gender (
    gender_id INT PRIMARY KEY IDENTITY(1,1),
    gender_name NVARCHAR(10) NOT NULL UNIQUE
);
GO

BULK INSERT Gender
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\GenderCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Customer Table Creation **********/
CREATE TABLE Customer (
    cust_id INT PRIMARY KEY IDENTITY(1,1),
    first_name NVARCHAR(30) NOT NULL,
    last_name NVARCHAR(30) NOT NULL,
    gender_id INT,
    phone NVARCHAR(20),
    addr NVARCHAR(40) NOT NULL,
    city_id INT NOT NULL,
    FOREIGN KEY (gender_id) REFERENCES Gender(gender_id),
    FOREIGN KEY (city_id) REFERENCES City(city_id)
);
GO

BULK INSERT Customer
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\CustomerCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Station Table Creation **********/
CREATE TABLE Station (
    station_id INT PRIMARY KEY IDENTITY(1,1),
    station_name NVARCHAR(30) NOT NULL UNIQUE
);
GO

BULK INSERT Station
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\StationCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Class Table Creation **********/
CREATE TABLE Class (
    class_id INT PRIMARY KEY IDENTITY(1,1),
    train_name NVARCHAR(20) NOT NULL UNIQUE
);
GO

BULK INSERT Class
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\ClassCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Train Table Creation **********/
CREATE TABLE Train (
    train_id INT PRIMARY KEY IDENTITY(1,1),
    train_name NVARCHAR(20) NOT NULL UNIQUE
);
GO

BULK INSERT Train
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\TrainCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Trip Table Creation **********/
CREATE TABLE Trip (
    trip_id INT PRIMARY KEY IDENTITY(1,1),
    trip_no NVARCHAR(20) NOT NULL UNIQUE,
    station_id_depart INT,
    station_id_arrive INT,
    depart_datetime DATETIME,
    arrive_datetime DATETIME,
    cost_paid DECIMAL(6,2),
    class_id INT,
    train_id INT,
    FOREIGN KEY (station_id_depart) REFERENCES Station(station_id),
    FOREIGN KEY (station_id_arrive) REFERENCES Station(station_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id),
    FOREIGN KEY (train_id) REFERENCES Train(train_id)
);
GO

BULK INSERT Trip
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\TripCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/********** Ticket Table Creation **********/
CREATE TABLE Ticket (
    ticket_id INT PRIMARY KEY IDENTITY(1,1),
    ticket_no NVARCHAR(20) NOT NULL UNIQUE,
    cust_id INT NOT NULL,
    trip_id INT NOT NULL,
    class_id INT NOT NULL,
    cost_paid DECIMAL(6,2),
    FOREIGN KEY (cust_id) REFERENCES Customer(cust_id),
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id)
);
GO

BULK INSERT Ticket
FROM 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\TicketCSV.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO


/* Sample Train Ticket: Train Booking System */
SELECT 
    t.ticket_no AS 'Confirmation Number',
    tr.train_name AS 'Train',
    c.train_name AS 'Class',
    s1.station_name AS 'Departure',
    s2.station_name AS 'Destination',
    FORMAT(trp.depart_datetime, 'MM/dd/yy hh:mmtt') AS 'Departure Date/Time',
    FORMAT(trp.arrive_datetime, 'MM/dd/yy hh:mmtt') AS 'Arrival Date/Time',
    cu.first_name + ' ' + cu.last_name AS 'Passenger(s)',
    t.ticket_no AS 'Ticket Number'
FROM Ticket t
INNER JOIN Customer cu ON t.cust_id = cu.cust_id
INNER JOIN Trip trp ON t.trip_id = trp.trip_id
INNER JOIN Station s1 ON trp.station_id_depart = s1.station_id
INNER JOIN Station s2 ON trp.station_id_arrive = s2.station_id
INNER JOIN Train tr ON trp.train_id = tr.train_id
INNER JOIN Class c ON trp.class_id = c.class_id;
GO






/************************************************************ Version 2 ************************************************************/
/********** Station Table Creation **********/
--Create Database IntroductoryProject;
USE IntroductoryProject;
GO

--Drop the table if it already exists
DROP TABLE IF EXISTS Ticket;
DROP TABLE IF EXISTS Trip;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Gender;
DROP TABLE IF EXISTS City;
DROP TABLE IF EXISTS State;
DROP TABLE IF EXISTS Class;
DROP TABLE IF EXISTS Station;
DROP TABLE IF EXISTS Train;
GO

/********** State Table Creation **********/
CREATE TABLE State (
    state_id INT PRIMARY KEY IDENTITY(1,1),
    state_name NVARCHAR(30) NOT NULL UNIQUE
);
GO

/********** City Table Creation **********/
CREATE TABLE City (
    city_id INT PRIMARY KEY IDENTITY(1,1),
    city_name NVARCHAR(30) NOT NULL,
    state_id INT NOT NULL,
    FOREIGN KEY (state_id) REFERENCES State(state_id)
);
GO

/********** Gender Table Creation **********/
CREATE TABLE Gender (
    gender_id INT PRIMARY KEY IDENTITY(1,1),
    gender_name NVARCHAR(10) NOT NULL UNIQUE
);
GO

/********** Customer Table Creation **********/
CREATE TABLE Customer (
    cust_id INT PRIMARY KEY IDENTITY(1,1),
    first_name NVARCHAR(30) NOT NULL,
    last_name NVARCHAR(30) NOT NULL,
    gender_id INT,
    phone NVARCHAR(20),
    addr NVARCHAR(40) NOT NULL,
    city_id INT NOT NULL,
    FOREIGN KEY (gender_id) REFERENCES Gender(gender_id),
    FOREIGN KEY (city_id) REFERENCES City(city_id)
);
GO

/********** Class Table Creation **********/
CREATE TABLE Class (
    class_id INT PRIMARY KEY IDENTITY(1,1),
    train_name NVARCHAR(20) NOT NULL UNIQUE
);
GO

/********** Station Table Creation **********/
CREATE TABLE Station (
    station_id INT PRIMARY KEY IDENTITY(1,1),
    station_name NVARCHAR(30) NOT NULL UNIQUE
);
GO

/********** Train Table Creation **********/
CREATE TABLE Train (
    train_id INT PRIMARY KEY IDENTITY(1,1),
    train_name NVARCHAR(20) NOT NULL UNIQUE
);
GO

/********** Trip Table Creation **********/
CREATE TABLE Trip (
    trip_id INT PRIMARY KEY IDENTITY(1,1),
    trip_no NVARCHAR(20) NOT NULL UNIQUE,
    station_id_depart INT,
    station_id_arrive INT,
    depart_datetime DATETIME,
    arrive_datetime DATETIME,
    cost_paid DECIMAL(6,2),
    class_id INT,
    train_id INT,
    FOREIGN KEY (station_id_depart) REFERENCES Station(station_id),
    FOREIGN KEY (station_id_arrive) REFERENCES Station(station_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id),
    FOREIGN KEY (train_id) REFERENCES Train(train_id)
);
GO

/********** Ticket Table Creation **********/
CREATE TABLE Ticket (
    ticket_id INT PRIMARY KEY IDENTITY(1,1),
    ticket_no NVARCHAR(20) NOT NULL UNIQUE,
    cust_id INT NOT NULL,
    trip_id INT NOT NULL,
    class_id INT NOT NULL,
    cost_paid DECIMAL(6,2),
    FOREIGN KEY (cust_id) REFERENCES Customer(cust_id),
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id)
);
GO

DECLARE @sql NVARCHAR(MAX);
--DECLARE @filePath NVARCHAR(255) = 'C:\Path\To\Your\Files\';
DECLARE @filePath NVARCHAR(255) = 'C:\Users\Ming Wang\Documents\SQL Server Management Studio\DBMS_2006_Introductory Project\';

-- Bulk Insert into State table from the CSV file
SET @sql = N'BULK INSERT State FROM ''' + @filePath + N'StateCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT City FROM ''' + @filePath + N'CityCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Gender FROM ''' + @filePath + N'GenderCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Customer FROM ''' + @filePath + N'CustomerCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Class FROM ''' + @filePath + N'ClassCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Station FROM ''' + @filePath + N'StationCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Train FROM ''' + @filePath + N'TrainCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Trip FROM ''' + @filePath + N'TripCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

-- Bulk Insert into City table from the CSV file
SET @sql = N'BULK INSERT Ticket FROM ''' + @filePath + N'TicketCSV.csv' +
           N''' WITH (FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'', FIRSTROW = 2);';
EXEC sp_executesql @sql;

/* Sample Train Ticket: Train Booking System */
SELECT 
    t.ticket_no AS 'Confirmation Number',
    tr.train_name AS 'Train',
    c.train_name AS 'Class',
    s1.station_name AS 'Departure',
    s2.station_name AS 'Destination',
    FORMAT(trp.depart_datetime, 'MM/dd/yy hh:mmtt') AS 'Departure Date/Time',
    FORMAT(trp.arrive_datetime, 'MM/dd/yy hh:mmtt') AS 'Arrival Date/Time',
    cu.first_name + ' ' + cu.last_name AS 'Passenger(s)',
    t.ticket_no AS 'Ticket Number'
FROM Ticket t
INNER JOIN Customer cu ON t.cust_id = cu.cust_id
INNER JOIN Trip trp ON t.trip_id = trp.trip_id
INNER JOIN Station s1 ON trp.station_id_depart = s1.station_id
INNER JOIN Station s2 ON trp.station_id_arrive = s2.station_id
INNER JOIN Train tr ON trp.train_id = tr.train_id
INNER JOIN Class c ON trp.class_id = c.class_id;
GO